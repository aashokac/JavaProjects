package com.example.demo.dao;

import com.example.demo.model.Employee;

public interface ILoginDao {
	
	public Employee getEmployeeDetails(Integer id);

}
