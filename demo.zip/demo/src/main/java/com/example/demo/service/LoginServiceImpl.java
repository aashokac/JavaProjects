package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.ILoginDao;
import com.example.demo.model.Employee;

@Service("iLoginService")
public class LoginServiceImpl implements ILoginService{

	@Autowired
	private ILoginDao iLoginDao;
	@Override
	public Employee getEmployeeDetails(Integer id) {
		// TODO Auto-generated method stub
		return iLoginDao.getEmployeeDetails(id);
	}

}
