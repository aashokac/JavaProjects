package com.example.demo.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import java.io.PrintWriter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Employee;
import com.example.demo.service.ILoginService;

@RestController
public class MainController {
	
	
	@Autowired
	private ILoginService iLoginService;
	
	@GetMapping("/login")
	public ModelAndView login() {
		
		Integer id=101;
	 System.out.println("spring boot application");
	 Employee emp=iLoginService.getEmployeeDetails(id);
	 System.out.println(emp.getEmployeeName());
	 ModelAndView mdv=new ModelAndView();
	 mdv.setViewName("login");
	 System.out.println(mdv.getViewName());
		return mdv;
		
	}

}
