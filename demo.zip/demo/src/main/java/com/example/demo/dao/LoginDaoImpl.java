package com.example.demo.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Employee;

@Repository("iLoginDao")
public class LoginDaoImpl implements ILoginDao{

	@PersistenceContext
	private	EntityManager entityManager;
	@Override
	public Employee getEmployeeDetails(Integer id) {
	
		return entityManager.find(Employee.class, id);
}
}
