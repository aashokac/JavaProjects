package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	
	@Id
	@GeneratedValue
	@Column(name="eid")
	private Integer id;
	@Column(name="ename")
	private String employeeName;
	@Column(name="esal")
	private Long salary;
	public Integer getId() {
		return id;
	}
	public Employee() {
		super();
	}
	public Employee(Integer id, String employeeName, Long salary) {
		super();
		this.id = id;
		this.employeeName = employeeName;
		this.salary = salary;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public Long getSalary() {
		return salary;
	}
	public void setSalary(Long salary) {
		this.salary = salary;
	}

}
