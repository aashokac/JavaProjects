package com.example.demo.service;

import com.example.demo.model.Employee;

public interface ILoginService {
	
	public Employee getEmployeeDetails(Integer id);

}
